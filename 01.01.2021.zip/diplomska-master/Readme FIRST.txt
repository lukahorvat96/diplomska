Please purchase the license before any commercial use.
My fonts for free use are allowed only in personal projects, and non-profit.
If you make money from using my fonts, Please purchase a commercial license.

Standard Commercial license :
-- https://fontbundles.net/typecoconut

-- https://creativemarket.com/typecoconut

For EXTENDED LICENSE, please contact me at typecoconut@gmail.com

----------------------------------------------

Thank you :)

CAUTION!
Anyone who uses personal use fonts for commercial needs without buying a commercial license and without permission from the author, will be subject to fines.


----------------------------------------------
----------------------------
menggunakan font ini untuk komersil tanpa membeli lisensinya dulu akan dikenakan 
biaya pelanggaran sebesar Rp 35.000.000 (tiga puluh lima juta rupiah).


BLA BLA TEST
