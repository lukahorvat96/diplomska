import Vue from "vue";
import VueRouter from "vue-router";
import Beers from "@/views/Home";
import Order from "@/views/Orders";
import OrderDetailById from "@/components/Order/OrderDetailById";

Vue.use(VueRouter);

const routes = [
  {
    path: "/home",
    name: "Home",
    component: Beers
  },
  {
    path: "/orders",
    name: "Orders",
    component: Order
  },
  {
    path: "/orders/:id",
    name: "Orders",
    component: OrderDetailById
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
